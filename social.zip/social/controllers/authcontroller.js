import validator from "validator";
import userModel from "../models/userModel.js";
import errormiddleware from "../middleware/erroemiddleware.js";

export const registercontroller = async (req, res, next) => {

    const { name, email, password } = req.body;

    if (!name) {
        next("name is required");
    }
    if (!email) {
        next("email is required");
    }
    if (!password) {
        next("password is required");
    }

    const existingUser = await userModel.findOne({ email });
    if (existingUser) {
        next('Email already register please login');
    }



    const user = await userModel.create({ name, email, password })

    // tokens
    const token = user.createJWT();
    res.status(201).send({
        success: true,
        message: 'user created successfully',
        user: {
            name: user.name,
            lastname: user.lastname,
            email: user.email,
            location: user.location,
        },
        token,
    });
};