import express from "express";
import { registercontroller } from "../controllers/authcontroller.js";


// creating router object
const router = express.Router();

// creating routes

router.post('/register', registercontroller);

export default router;

